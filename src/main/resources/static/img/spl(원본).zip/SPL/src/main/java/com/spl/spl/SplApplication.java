package com.spl.spl;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SplApplication {

    public static void main(String[] args) {
        SpringApplication.run(SplApplication.class, args);
    }

}
